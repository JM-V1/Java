//original fx program
package application;
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.Button;
import javafx.scene.transform.Rotate;
import javafx.scene.control.Labeled;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;





public class Main extends Application  {


	@Override
	public void start(Stage primaryStage){
		// TODO Auto-generated method stub
		//stage 
		Stage stage = new  Stage();
		Group root = new Group();
		Scene scene = new Scene(root,500,500);
		
		//rectangle
		Rectangle rectangle = new Rectangle();
		
		rectangle.setWidth(80);
		rectangle.setHeight(175);
		
		rectangle.setX(200);
		rectangle.setY(150);
		rectangle.setFill(Color.BLACK);
		
		//button
		Button button = new Button("rotate 15 degrees");
		button.setLayoutX(185);
		button.setLayoutY(380);
		
		//rotating the rectangle

		

		
		//button action event
		button.setOnAction(new EventHandler <ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				Rotate rotate = new Rotate();
				rotate.setAngle(15);
				rotate.setPivotX(250); //180
				rotate.setPivotY(250); //350
				rectangle.getTransforms().add(rotate);
			}
			
			
		});
		
		
		
		
		root.getChildren().add(rectangle);
		root.getChildren().add(button);
		stage.setResizable(true);
		primaryStage.setTitle("Rotating Rectangle");
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);

	}

}

